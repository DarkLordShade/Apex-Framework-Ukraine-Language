19/02/2018 A3 1.80

- These are mission.SQM files for using on the supported terrains.
- If you create large custom composition in Eden Editor, and then use Default Base Layout in parameters, this will create a lot of wear and tear (lag + desync) on the server to delete all these entities prior to building the default base. If you are going to regularly use the Default Base Layout, its advised to use one of these Vanilla SQM files with as little as possible created in the editor (since it will all be deleted at mission start).